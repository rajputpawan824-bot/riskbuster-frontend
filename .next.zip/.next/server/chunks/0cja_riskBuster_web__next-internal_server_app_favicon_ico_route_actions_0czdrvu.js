module.exports=[91935,(e,o,d)=>{}];

//# sourceMappingURL=0cja_riskBuster_web__next-internal_server_app_favicon_ico_route_actions_0czdrvu.js.map
module.exports=[73356,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_riskBuster_riskBuster_web__next-internal_server_app_page_actions_0-cl360.js.map
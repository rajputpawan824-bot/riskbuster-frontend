module.exports=[23388,(a,b,c)=>{}];

//# sourceMappingURL=0amv_riskBuster_riskBuster_web__next-internal_server_app_about_page_actions_0-e4thn.js.map
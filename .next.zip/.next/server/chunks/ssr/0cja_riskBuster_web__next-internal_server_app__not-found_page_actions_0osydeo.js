module.exports=[46162,(a,b,c)=>{}];

//# sourceMappingURL=0cja_riskBuster_web__next-internal_server_app__not-found_page_actions_0osydeo.js.map
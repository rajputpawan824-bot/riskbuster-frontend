module.exports=[25692,(a,b,c)=>{}];

//# sourceMappingURL=0cja_riskBuster_web__next-internal_server_app__global-error_page_actions_03yq35p.js.map
var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0arv.vj._.js")
R.c("server/chunks/[root-of-the-server]__0m17wk0._.js")
R.c("server/chunks/0cja_riskBuster_web__next-internal_server_app_favicon_ico_route_actions_0czdrvu.js")
R.m(74267)
module.exports=R.m(74267).exports

1:"$Sreact.fragment"
2:I[95081,["/_next/static/chunks/0uv9~atiznzof.js","/_next/static/chunks/0.o2vjany6var.js"],"default"]
3:I[62463,["/_next/static/chunks/0uv9~atiznzof.js","/_next/static/chunks/0.o2vjany6var.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"A7isEkvEz7peP12ZoJylP"}

globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/A7isEkvEz7peP12ZoJylP/_buildManifest.js",
    "static/A7isEkvEz7peP12ZoJylP/_ssgManifest.js",
    "static/A7isEkvEz7peP12ZoJylP/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/10-5-0dxzvyho.js",
    "static/chunks/0b8a-fx4_k-n2.js",
    "static/chunks/08kxx9lw~fj-m.js",
    "static/chunks/turbopack-0nlb8.du2dti-.js"
  ]
};
